﻿using System;
using System.Collections;
using System.Collections.Generic;
using StarterGame.Rooms;
using static StarterGame.Rooms.Room;

namespace StarterGame
{
    public class GameWorld
    {
        public GameWorld()
        {
            //Room foyer = new Room("in  building");
            //Room kitchen = new Room("What a Spectacular kitchen!");

            ////Create and drop items in rooms
            //IItem item = new Item("House Brochure", 1.5f, 2f);
            //foyer.Drop(item);

            //IItemContainer chest = new ItemContainer("chest");
            //kitchen.Drop(chest);
            //item = new Item("Money", 0.1f, 50f);
            //chest.Insert(item);

            ////Setup rooms delegates
            //IRoomDelegate echoRoom = new EchoRoom();
            //familyroom.Delegate = echoRoom;
            ////echoRoom.ContainingRoom  = familyroom;

            //IRoomDelegate trapRoom = new TrapRoom();
            //primarycloset.Delegate = trapRoom;
            ////trapRoom.ContainingRoom  = primarycloset;

        }
    }
}

